from .app import entry_point

entry_point()
