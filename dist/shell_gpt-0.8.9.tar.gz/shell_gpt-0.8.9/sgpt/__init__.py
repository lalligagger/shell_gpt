from .app import main as main
from .app import entry_point as cli  # noqa: F401

__version__ = "0.8.9"
